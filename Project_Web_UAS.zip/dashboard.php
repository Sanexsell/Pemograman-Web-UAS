<?php
session_start();

// Cek login [cite: 71-74]
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Modern Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; overflow-x: hidden;}
        /* Styling Sidebar */
        .sidebar { background: #1e3c72; min-height: 100vh; color: #fff; box-shadow: 4px 0 10px rgba(0,0,0,0.1); }
        .sidebar a { color: #cfd8dc; text-decoration: none; display: block; padding: 15px 25px; transition: 0.3s; font-weight: 500;}
        .sidebar a:hover { background: rgba(255,255,255,0.1); color: #fff; padding-left: 30px;}
        .sidebar .active { background: rgba(255,255,255,0.15); color: #fff; border-left: 4px solid #00c6ff; }
        
        /* Styling Navbar */
        .navbar-custom { background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .content-area { padding: 30px; }
    </style>
</head>
<body>
    <div class="d-flex">
        
        <div class="sidebar" style="width: 260px;">
            <h4 class="text-center py-4 border-bottom border-secondary m-0 font-weight-bold">
                <i class="fas fa-cubes mr-2 text-info"></i>Admin Panel
            </h4>
            <div class="mt-3">
                <a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt mr-3"></i> Dashboard</a>
                <a href="user.php"><i class="fas fa-users mr-3"></i> Manajemen User</a>
                <a href="barang.php"><i class="fas fa-box mr-3"></i> Data Barang (UAS)</a>
            </div>
        </div>

        <div class="flex-grow-1">
            
            <nav class="navbar navbar-expand navbar-light navbar-custom px-4 py-3">
                <ul class="navbar-nav ml-auto align-items-center">
                    
                    <li class="nav-item mr-4">
                        <span class="font-weight-bold text-dark">
                            <i class="fas fa-user-circle text-primary mr-1" style="font-size: 1.2rem; vertical-align: middle;"></i> 
                            <?= htmlspecialchars($_SESSION['username']); ?>
                        </span>
                    </li>
                    
                    <li class="nav-item">
                        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-4 shadow-sm" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                            <i class="fas fa-sign-out-alt mr-1"></i> Logout
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="content-area">
                <h2 class="mb-4 font-weight-bold">Selamat Datang, <?= htmlspecialchars($_SESSION['username']); ?>! 👋</h2>
                
                <div class="card border-0 shadow-sm rounded-lg">
                    <div class="card-body p-5 text-center">
                        <h5 class="text-muted font-weight-light">Pilih menu di bawah atau di samping untuk mengelola sistem.</h5>
                        <hr class="my-5">
                        
                        <div class="row justify-content-center">
                            <div class="col-md-4 mb-3">
                                <div class="p-4 bg-light rounded-lg shadow-sm border text-center h-100">
                                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                        <i class="fas fa-users fa-2x"></i>
                                    </div>
                                    <h4>Kelola User</h4>
                                    <a href="user.php" class="btn btn-outline-primary btn-sm rounded-pill mt-3 px-4">Buka Data User</a>
                                </div>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <div class="p-4 bg-light rounded-lg shadow-sm border text-center h-100">
                                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 70px; height: 70px;">
                                        <i class="fas fa-box fa-2x"></i>
                                    </div>
                                    <h4>Data Barang</h4>
                                    <a href="barang.php" class="btn btn-outline-success btn-sm rounded-pill mt-3 px-4">Buka Data Barang</a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</body>
</html>