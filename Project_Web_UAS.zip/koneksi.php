<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "db_toko";

// Tambahkan tanda sama dengan (=) dan garis bawah (_) yang hilang
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>