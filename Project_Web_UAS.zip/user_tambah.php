<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah User - Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card-form { max-width: 500px; margin: 50px auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card card-form border-0 shadow-lg rounded-lg">
            <div class="card-header bg-primary text-white text-center py-3 border-0">
                <h5 class="m-0 font-weight-bold"><i class="fas fa-user-plus mr-2"></i>Tambah User Baru</h5>
            </div>
            <div class="card-body p-4">
                <form action="action/tambah_user_proses.php" method="post">
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control rounded" required placeholder="Masukkan username...">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control rounded" required placeholder="Masukkan password...">
                    </div>
                    <div class="mt-4">
                        <button type="submit" name="tambah_user" class="btn btn-primary btn-block rounded-pill">Simpan Data</button>
                        <a href="user.php" class="btn btn-secondary btn-block rounded-pill">Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>