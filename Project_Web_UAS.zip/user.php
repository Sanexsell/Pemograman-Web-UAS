<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}

// Mengambil data user
$query = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen User - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
    
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; overflow-x: hidden;}
        .sidebar { background: #1e3c72; min-height: 100vh; color: #fff; box-shadow: 4px 0 10px rgba(0,0,0,0.1); }
        .sidebar a { color: #cfd8dc; text-decoration: none; display: block; padding: 15px 25px; transition: 0.3s; font-weight: 500;}
        .sidebar a:hover { background: rgba(255,255,255,0.1); color: #fff; padding-left: 30px;}
        .sidebar .active { background: rgba(255,255,255,0.15); color: #fff; border-left: 4px solid #00c6ff; }
        .navbar-custom { background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .content-area { padding: 30px; }
    </style>
</head>
<body>
    <div class="d-flex">
        
        <div class="sidebar" style="width: 260px;">
            <h4 class="text-center py-4 border-bottom border-secondary m-0 font-weight-bold">
                <i class="fas fa-cubes mr-2 text-info"></i>Admin Panel
            </h4>
            <div class="mt-3">
                <a href="dashboard.php"><i class="fas fa-tachometer-alt mr-3"></i> Dashboard</a>
                <a href="user.php" class="active"><i class="fas fa-users mr-3"></i> Manajemen User</a>
                <a href="barang.php"><i class="fas fa-box mr-3"></i> Data Barang (UAS)</a>
            </div>
        </div>

        <div class="flex-grow-1">
            
            <nav class="navbar navbar-expand navbar-light navbar-custom px-4 py-3">
                <ul class="navbar-nav ml-auto align-items-center">
                    <li class="nav-item mr-4">
                        <span class="font-weight-bold text-dark">
                            <i class="fas fa-user-circle text-primary mr-1"></i> <?= htmlspecialchars($_SESSION['username']); ?>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-4 shadow-sm" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                            <i class="fas fa-sign-out-alt mr-1"></i> Logout
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="content-area">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="font-weight-bold m-0">Data Manajemen User</h2>
                    <a href="user_tambah.php" class="btn btn-primary rounded-pill shadow-sm px-4">
                        <i class="fas fa-user-plus mr-1"></i> Tambah User Baru
                    </a>
                </div>
                
                <div class="card border-0 shadow-sm rounded-lg">
                    <div class="card-body">
                        <table id="tabelUser" class="table table-hover border-0">
                            <thead class="bg-light">
                                <tr>
                                    <th width="10%" class="text-center">No</th>
                                    <th>Username</th>
                                    <th width="20%" class="text-center">Status Akun</th>
                                    <th width="15%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                while ($row = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td class="text-center align-middle"><?= $no++; ?></td>
                                    <td class="align-middle font-weight-bold">
                                        <i class="fas fa-user text-secondary mr-2"></i><?= htmlspecialchars($row['username']); ?>
                                    </td>
                                    <td class="text-center align-middle">
                                        <span class="badge badge-success badge-pill px-3 py-2"><i class="fas fa-check-circle mr-1"></i> Aktif</span>
                                    </td>
                                    
                                    <td class="align-middle">
                                        <div class="d-flex flex-column align-items-center">
                                            <a href="#" class="btn btn-success btn-sm rounded-pill shadow-sm mb-2" data-toggle="modal" data-target="#editUserModal<?= $row['id']; ?>" style="width: 90px;">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>

                                            <a href="user_delete.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm rounded-pill shadow-sm" onclick="return confirm('Yakin ingin menghapus user ini?')" style="width: 90px;">
                                                <i class="fas fa-trash"></i> Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>

                                <div class="modal fade" id="editUserModal<?= $row['id']; ?>" tabindex="-1" role="dialog">
                                    <div class="modal-dialog">
                                        <div class="modal-content border-0 shadow-lg">
                                            <div class="modal-header border-bottom-0">
                                                <h5 class="modal-title font-weight-bold">
                                                    <i class="fas fa-user-edit text-success mr-2"></i>Update Data User
                                                </h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            
                                            <div class="modal-body bg-light">
                                                <form action="action/ubah_user.php" method="post">
                                                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                                    
                                                    <div class="form-group">
                                                        <label>Username</label>
                                                        <input type="text" name="username" class="form-control rounded" value="<?= htmlspecialchars($row['username']); ?>" required>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label>Password Baru (Kosongkan jika tidak ingin diubah)</label>
                                                        <input type="password" name="password" class="form-control rounded" placeholder="Ketik password baru...">
                                                    </div>
                                                    
                                                    <div class="modal-footer border-top-0 px-0 pb-0 mt-3">
                                                        <button type="button" class="btn btn-secondary rounded-pill px-4" data-dismiss="modal">Batal</button>
                                                        <button type="submit" name="update_user" class="btn btn-success rounded-pill px-4">Simpan Perubahan</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tabelUser').DataTable({
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "language": {
                    "search": "Cari User:",
                    "lengthMenu": "Tampilkan _MENU_ user per halaman",
                    "zeroRecords": "User tidak ditemukan",
                    "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                    "infoEmpty": "Tidak ada data yang tersedia",
                    "paginate": { "next": "Selanjutnya", "previous": "Sebelumnya" }
                }
            });
        });
    </script>
</body>
</html>