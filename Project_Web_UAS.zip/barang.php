<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}

// Mengambil data barang
$query = mysqli_query($conn, "SELECT * FROM barang ORDER BY id_barang DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang - Admin Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
    
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; overflow-x: hidden;}
        .sidebar { background: #1e3c72; min-height: 100vh; color: #fff; box-shadow: 4px 0 10px rgba(0,0,0,0.1); }
        .sidebar a { color: #cfd8dc; text-decoration: none; display: block; padding: 15px 25px; transition: 0.3s; font-weight: 500;}
        .sidebar a:hover { background: rgba(255,255,255,0.1); color: #fff; padding-left: 30px;}
        .sidebar .active { background: rgba(255,255,255,0.15); color: #fff; border-left: 4px solid #00c6ff; }
        .navbar-custom { background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .content-area { padding: 30px; }
    </style>
</head>
<body>
    <div class="d-flex">
        
        <div class="sidebar" style="width: 260px;">
            <h4 class="text-center py-4 border-bottom border-secondary m-0 font-weight-bold">
                <i class="fas fa-cubes mr-2 text-info"></i>Admin Panel
            </h4>
            <div class="mt-3">
                <a href="dashboard.php"><i class="fas fa-tachometer-alt mr-3"></i> Dashboard</a>
                <a href="user.php"><i class="fas fa-users mr-3"></i> Manajemen User</a>
                <a href="barang.php" class="active"><i class="fas fa-box mr-3"></i> Data Barang (UAS)</a>
            </div>
        </div>

        <div class="flex-grow-1">
            
            <nav class="navbar navbar-expand navbar-light navbar-custom px-4 py-3">
                <ul class="navbar-nav ml-auto align-items-center">
                    <li class="nav-item mr-4">
                        <span class="font-weight-bold text-dark">
                            <i class="fas fa-user-circle text-primary mr-1"></i> <?= htmlspecialchars($_SESSION['username']); ?>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="btn btn-danger btn-sm rounded-pill px-4 shadow-sm" onclick="return confirm('Apakah Anda yakin ingin logout?')">
                            <i class="fas fa-sign-out-alt mr-1"></i> Logout
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="content-area">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="font-weight-bold m-0">Data Master Barang</h2>
                    <a href="barang_tambah.php" class="btn btn-primary rounded-pill shadow-sm px-4">
                        <i class="fas fa-plus mr-1"></i> Tambah Barang Baru
                    </a>
                </div>
                
                <div class="card border-0 shadow-sm rounded-lg">
                    <div class="card-body">
                        <table id="tabelBarang" class="table table-hover border-0">
                           <thead class="bg-light">
                                <tr>
                                    <th width="5%" class="text-center">No</th>
                                    <th>Kode Barang</th>
                                    <th>Nama Barang</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    <th class="text-center">Stok</th>
                                    <th width="10%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                while ($row = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td class="text-center"><?= $no++; ?></td>
                                    <td><span class="badge badge-secondary"><?= htmlspecialchars($row['kode_barang']); ?></span></td>
                                    <td class="font-weight-bold"><?= htmlspecialchars($row['nama_barang']); ?></td>
                                    <td><?= htmlspecialchars($row['kategori']); ?></td>
                                    <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                                    <td class="text-center">
                                        <span class="badge <?= ($row['stok'] > 10) ? 'badge-success' : 'badge-danger'; ?> badge-pill px-3 py-2">
                                            <?= htmlspecialchars($row['stok']); ?>
                                        </span>
                                    </td>
                                    
                                    <td class="align-middle">
                                        <div class="d-flex flex-column align-items-center">
                                            <a href="#" class="btn btn-success btn-sm rounded-pill shadow-sm mb-2" data-toggle="modal" data-target="#editModal<?= $row['id_barang']; ?>" style="width: 90px;">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                    
                                            <a href="barang_delete.php?id=<?= $row['id_barang']; ?>" class="btn btn-danger btn-sm rounded-pill shadow-sm" onclick="return confirm('Yakin ingin menghapus barang ini?')" style="width: 90px;">
                                                <i class="fas fa-trash"></i> Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                </tr> <div class="modal fade" id="editModal<?= $row['id_barang']; ?>" tabindex="-1" role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content border-0 shadow-lg">
                                        <div class="modal-header border-bottom-0">
                                            <h5 class="modal-title font-weight-bold">
                                                <i class="fas fa-edit text-success mr-2"></i>Update Data Barang
                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        
                                        <div class="modal-body bg-light">
                                            <form action="action/ubah_barang.php" method="post">
                                                <input type="hidden" name="id_barang" value="<?= $row['id_barang']; ?>">
                                                
                                                <div class="form-group">
                                                    <label>Kode Barang</label>
                                                    <input type="text" name="kode_barang" class="form-control rounded" value="<?= htmlspecialchars($row['kode_barang']); ?>" required readonly>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Nama Barang</label>
                                                    <input type="text" name="nama_barang" class="form-control rounded" value="<?= htmlspecialchars($row['nama_barang']); ?>" required>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label>Kategori</label>
                                                    <select name="kategori" class="form-control rounded" required>
                                                        <option value="Elektronik" <?= ($row['kategori'] == 'Elektronik') ? 'selected' : ''; ?>>Elektronik</option>
                                                        <option value="Furniture" <?= ($row['kategori'] == 'Furniture') ? 'selected' : ''; ?>>Furniture</option>
                                                        <option value="Pakaian" <?= ($row['kategori'] == 'Pakaian') ? 'selected' : ''; ?>>Pakaian</option>
                                                        <option value="Makanan" <?= ($row['kategori'] == 'Makanan') ? 'selected' : ''; ?>>Makanan</option>
                                                    </select>
                                                </div>
                                                
                                                <div class="row">
                                                    <div class="col-md-6 form-group">
                                                        <label>Harga (Rp)</label>
                                                        <input type="number" name="harga" class="form-control rounded" value="<?= $row['harga']; ?>" required>
                                                    </div>
                                                    <div class="col-md-6 form-group">
                                                        <label>Stok</label>
                                                        <input type="number" name="stok" class="form-control rounded" value="<?= $row['stok']; ?>" required>
                                                    </div>
                                                </div>
                                                
                                                <div class="modal-footer border-top-0 px-0 pb-0 mt-3">
                                                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-dismiss="modal">Batal</button>
                                                    <button type="submit" name="update_barang" class="btn btn-success rounded-pill px-4">Simpan Perubahan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                </div>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
    </div>

   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tabelBarang').DataTable({
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "language": {
                    "search": "Cari Barang:",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Barang tidak ditemukan",
                    "info": "Menampilkan halaman _PAGE_ dari _PAGES_",
                    "infoEmpty": "Tidak ada data yang tersedia",
                    "paginate": { "next": "Selanjutnya", "previous": "Sebelumnya" }
                }
            });
        });
    </script>
</body>
</html>