<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once "koneksi.php";

$error = "";
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    // Cek user di database [cite: 45-46]
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) { // [cite: 48]
        // Jika data ditemukan, set session login [cite: 49-52]
        $_SESSION['login'] = true;
        $_SESSION['username'] = $username;
        header("Location: dashboard.php"); // 
        exit();
    } else {
        $error = "Username atau Password salah!"; // [cite: 55]
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Modern CRUD</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            height: 100vh;
            overflow: hidden;
        }
        .login-container {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.95);
            border: none;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
            width: 100%;
            max-width: 430px;
        }
        .login-card:hover {
            transform: translateY(-5px);
        }
        .brand-icon {
            background: linear-gradient(135deg, #00c6ff 0%, #0072ff 100%);
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 30px;
            margin: 0 auto 20px;
            box-shadow: 0 5px 15px rgba(0, 114, 255, 0.4);
        }
        .form-control {
            background: #f4f6f9;
            border: 2px solid transparent;
            border-radius: 12px;
            height: 50px;
            padding-left: 45px;
            font-weight: 400;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            background: #fff;
            border-color: #0072ff;
            box-shadow: none;
        }
        .input-group-icon {
            position: absolute;
            left: 18px;
            top: 16px;
            color: #a0a5b5;
            transition: all 0.3s ease;
            z-index: 10;
        }
        .form-group:focus-within .input-group-icon {
            color: #0072ff;
        }
        .btn-login {
            background: linear-gradient(135deg, #0072ff 0%, #00c6ff 100%);
            border: none;
            border-radius: 12px;
            height: 50px;
            font-weight: 600;
            font-size: 16px;
            letter-spacing: 0.5px;
            box-shadow: 0 5px 15px rgba(0, 114, 255, 0.3);
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #005cff 0%, #00b3ff 100%);
            transform: scale(1.02);
            box-shadow: 0 7px 20px rgba(0, 114, 255, 0.4);
        }
        .alert-custom {
            background-color: #ffeef0;
            border-left: 4px solid #ff4d4d;
            color: #d93838;
            border-radius: 8px;
            font-size: 14px;
            animation: shake 0.4s ease-in-out;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-6px); }
            75% { transform: translateX(6px); }
        }
    </style>
</head>
<body>
    
    <div class="container login-container">
        <div class="card login-card p-4">
            <div class="card-body">
                
                <div class="brand-icon">
                    <i class="fas fa-cubes"></i>
                </div>
                
                <h3 class="text-center font-weight-bold text-dark mb-1">Welcome Back</h3>
                <p class="text-center text-muted small mb-4">Silakan masuk ke sistem manajemen toko</p>
                
                <?php if ($error != ""): ?>
                    <div class="alert alert-custom p-3 text-center mb-3">
                        <i class="fas fa-exclamation-circle mr-2"></i> <?= $error; ?>
                    </div>
                <?php endif; ?>
                
                <form action="login.php" method="post">
                    <div class="form-group position-relative mb-3">
                        <i class="fas fa-user input-group-icon"></i>
                        <input type="text" name="username" class="form-control" placeholder="Masukkan Username" required autocomplete="off"> 
                    </div>
                    
                    <div class="form-group position-relative mb-4">
                        <i class="fas fa-lock input-group-icon"></i>
                        <input type="password" name="password" class="form-control" placeholder="Masukkan Password" required> 
                    </div>
                    
                    <button type="submit" name="login" class="btn btn-primary btn-block btn-login text-white">
                        Sign In <i class="fas fa-arrow-right ml-2"></i>
                    </button>
                </form>
                
            </div>
        </div>
    </div>

</body>
</html>