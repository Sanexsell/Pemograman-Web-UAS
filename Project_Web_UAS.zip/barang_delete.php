<?php
session_start();
require_once "koneksi.php";

// Proteksi halaman agar hanya admin yang sudah login yang bisa akses
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}

// Mengecek apakah ada ID yang dikirim dari tombol hapus
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: barang.php");
    exit();
}

// Menangkap ID barang
$id = (int) $_GET['id'];

// Mengeksekusi query hapus menggunakan prepared statement agar aman
$stmt = mysqli_prepare($conn, "DELETE FROM barang WHERE id_barang=?");
mysqli_stmt_bind_param($stmt, "i", $id);

// Mengecek apakah proses hapus berhasil
if (mysqli_stmt_execute($stmt)) {
    echo "<script>alert('Data barang berhasil dihapus!'); window.location='barang.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data barang!'); window.location='barang.php';</script>";
}
?>