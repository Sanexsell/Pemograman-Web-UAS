<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['simpan'])) {
    $kode_barang = $_POST['kode_barang'];
    $nama_barang = $_POST['nama_barang'];
    $kategori = $_POST['kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $query = "INSERT INTO barang (kode_barang, nama_barang, kategori, harga, stok) 
              VALUES ('$kode_barang', '$nama_barang', '$kategori', '$harga', '$stok')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data barang berhasil ditambahkan!'); window.location='barang.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data! Kode barang mungkin sudah ada.'); window.location='barang_tambah.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Barang</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style> body { font-family: 'Poppins', sans-serif; background-color: #f4f6f9; } </style>
</head>
<body class="d-flex align-items-center justify-content-center" style="height: 100vh;">

    <div class="card shadow-sm border-0 rounded-lg" style="width: 500px;">
        <div class="card-header bg-white border-0 pt-4 pb-0">
            <h4 class="font-weight-bold text-center">Tambah Master Barang</h4>
        </div>
        <div class="card-body p-4">
            <form action="" method="post">
                <div class="form-group">
                    <label>Kode Barang</label>
                    <input type="text" name="kode_barang" class="form-control rounded" placeholder="Contoh: BRG-003" required>
                </div>
                <div class="form-group">
                    <label>Nama Barang</label>
                    <input type="text" name="nama_barang" class="form-control rounded" required>
                </div>
                <div class="form-group">
                    <label>Kategori</label>
                    <select name="kategori" class="form-control rounded" required>
                        <option value="">-- Pilih Kategori --</option>
                        <option value="Elektronik">Elektronik</option>
                        <option value="Furniture">Furniture</option>
                        <option value="Pakaian">Pakaian</option>
                        <option value="Makanan">Makanan</option>
                    </select>
                </div>
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control rounded" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label>Stok Awal</label>
                        <input type="number" name="stok" class="form-control rounded" required>
                    </div>
                </div>
                
                <div class="mt-4 text-center">
                    <a href="barang.php" class="btn btn-light rounded-pill px-4 mr-2">Batal</a>
                    <button type="submit" name="simpan" class="btn btn-primary rounded-pill px-4">Simpan Barang</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>