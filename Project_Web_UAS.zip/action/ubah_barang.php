<?php
session_start();
// Naik satu level folder untuk memanggil koneksi
require_once "../koneksi.php"; 

if (isset($_POST['update_barang'])) {
    $id_barang = (int) $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $kategori = $_POST['kategori'];
    $harga = (int) $_POST['harga'];
    $stok = (int) $_POST['stok'];

    // Query untuk melakukan Update data ke database
    $query = "UPDATE barang SET 
              nama_barang = '$nama_barang', 
              kategori = '$kategori', 
              harga = '$harga', 
              stok = '$stok' 
              WHERE id_barang = $id_barang";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data barang berhasil diperbarui!'); window.location='../barang.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data barang!'); window.location='../barang.php';</script>";
    }
} else {
    // Redirect jika halaman diakses secara langsung tanpa form
    header("Location: ../barang.php");
    exit();
}
?>