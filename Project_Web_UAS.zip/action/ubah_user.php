<?php
session_start();
require_once "../koneksi.php"; 

if (isset($_POST['update_user'])) {
    $id = (int) $_POST['id'];
    $username = $_POST['username'];
    $password_baru = $_POST['password'];

    // Cek apakah password diisi atau dikosongkan
    if (empty($password_baru)) {
        // Jika kosong, update username saja
        $query = "UPDATE users SET username = '$username' WHERE id = $id";
    } else {
        // Jika password diisi, update username dan password (harap diingat: ideally gunakan password_hash)
        $query = "UPDATE users SET username = '$username', password = '$password_baru' WHERE id = $id";
    }

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data user berhasil diperbarui!'); window.location='../user.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data user!'); window.location='../user.php';</script>";
    }
} else {
    header("Location: ../user.php");
    exit();
}
?>