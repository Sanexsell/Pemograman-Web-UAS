<?php
session_start();
// Hati-hati dengan path koneksi, karena file ini ada di dalam folder 'action'
// Kita harus naik satu folder menggunakan '../'
require_once "../koneksi.php"; 

if (isset($_POST['submit'])) {
    $id = $_POST['id_user'];
    $username = $_POST['username'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $password_baru = $_POST['password'];

    // Cek apakah password baru diisi atau tidak
    if (!empty($password_baru)) {
        // Jika password diisi, update semua termasuk password
        $query = "UPDATE users SET username='$username', password='$password_baru', nama_lengkap='$nama_lengkap' WHERE id='$id'";
    } else {
        // Jika password dikosongkan, update data tanpa mengubah password lama
        $query = "UPDATE users SET username='$username', nama_lengkap='$nama_lengkap' WHERE id='$id'";
    }

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data user berhasil diperbarui!'); window.location='../user.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data!'); window.location='../user.php';</script>";
    }
} else {
    // Jika file diakses langsung tanpa form
    header("Location: ../user.php");
    exit();
}
?>