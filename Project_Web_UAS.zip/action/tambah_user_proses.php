<?php
require_once "../koneksi.php";

if (isset($_POST['tambah_user'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Ingat: untuk produksi, gunakan password_hash()

    $query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('User berhasil ditambahkan!'); window.location='../user.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah user!'); window.location='../user_tambah.php';</script>";
    }
}
?>