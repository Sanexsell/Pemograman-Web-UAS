<?php
// Dua baris ini akan memaksa browser menampilkan pesan jika ada error
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Perbaikan penulisan $_SESSION dan kurung kurawal
if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: login.php");
    exit();
}
?>