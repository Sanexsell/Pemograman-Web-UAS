<?php
session_start();
require_once "koneksi.php";
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit();
}
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: user.php");
    exit();
}
$id = (int) $_GET['id'];
$stmt = mysqli_prepare($conn, "DELETE FROM users WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    echo "<script>alert('Data user berhasil dihapus'); window.location='user.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus data user'); window.location='user.php';</script>";
}
?>